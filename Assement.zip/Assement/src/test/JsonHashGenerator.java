package test;
import java.io.FileReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class JsonHashGenerator {

    public static void main(String[] args) throws ParseException {
//        if (args.length < 2) {
//            System.out.println("Please provide the PRN number and JSON file location as command-line arguments.");
//            return;
//        }
//
        String prnNumber = args[0];
        String jsonFilePath = args[1];

        try {
            // Step 2: Read and Parse JSON File
        	FileReader reader = new FileReader(jsonFilePath);
            
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonObject = (JSONObject) jsonParser.parse(reader);
            // Step 3: Traverse JSON and find "destination" value
            Object destinationValue = findDestinationValue(jsonObject);
            if (destinationValue == null) {
                System.out.println("The 'destination' key is not found in the JSON file.");
                return;
            }

            // Step 4: Generate a random alphanumeric string of size 8 characters
            String randomString = generateRandomString(8);

            // Step 5: Generate hash from concatenated string
            String concatenatedString = prnNumber + destinationValue + randomString;
            String hashValue = generateHash(concatenatedString);


            // Step 6: Format and print the output
            String result = hashValue + ";" + randomString;
            System.out.println(result);

        } catch (IOException e) {
            System.out.println("Error reading the JSON file: " + e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Error generating hash: " + e.getMessage());
        }
    }

    // Method to find the first instance of "destination" key in JSON
    public static Object findDestinationValue(JSONObject jsonObject) {
    	
    	Set<String> keys = jsonObject.keySet();
        for (Object key : keys) {
            Object value = jsonObject.get(key);

            if (key.equals("destination")) {
                return value; // Return the first occurrence of the target key
            }

            if (value instanceof JSONObject) {
                Object foundValue = findDestinationValue((JSONObject) value);
                if (foundValue != null) {
                    return foundValue;
                }
            }
        }
        return null; // Return null if the target key is not found
    }

    // Method to generate a random alphanumeric string of a given length
    public static String generateRandomString(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    // Method to generate a hash using SHA-256
    public static String generateHash(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}

